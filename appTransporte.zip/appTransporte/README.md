# appTransporte - CRUD de db_paqueteria (Java Swing + MySQL)

CRUD completo con validaciones para las tablas `camion`, `camionero`, `camionerocamion`,
`paquete` y `ciudad` de la base de datos `db_paqueteria`.

## Requisitos
- JDK 21 y Maven (o NetBeans con Maven)
- MySQL con la base `db_paqueteria`

## Configuración de la conexión
1. Copia `src/main/resources/db.properties.example` como `src/main/resources/db.properties`.
2. Escribe tu usuario y contraseña de MySQL.

`db.properties` está en `.gitignore`, así que tu contraseña no se sube a GitHub.

## Ejecutar
- NetBeans: clic derecho en el proyecto > Run (clase principal `umg.UI.AppTransporte`).
- Consola: `mvn compile exec:java -Dexec.mainClass=umg.UI.AppTransporte`

## Estructura (una ventana por tabla)
| Tabla            | Modelo (`umg.modelo`) | DAO (`umg.DAO`)        | Ventana (`umg.UI`)      |
|------------------|-----------------------|------------------------|-------------------------|
| `camion`         | `Camion`              | `CamionDAO`            | `FrmCamion`             |
| `camionero`      | `Camionero`           | `CamioneroDAO`         | `FrmCamionero`          |
| `camionerocamion`| `CamioneroCamion`     | `CamioneroCamionDAO`   | `FrmCamioneroCamion`    |
| `paquete`        | `Paquete`             | `PaqueteDAO`           | `FrmPaquete`            |
| `ciudad`         | `Ciudad`              | `CiudadDAO`            | `FrmCiudad`             |

- `umg.UI.FrmPrincipal`: menú principal, un botón por ventana.
- `umg.util`: validaciones reutilizables (`Validador`, `ValidacionException`).
- `umg.UI.UiUtil` / `umg.UI.ItemCombo`: apoyo común de las ventanas.

Todas las ventanas son formularios de NetBeans (`.java` + `.form`): se abren en la pestaña
**Design** para mover o editar componentes. La lógica (guardar, actualizar, eliminar, validar)
está fuera de las zonas azules del código, así que NetBeans no la sobrescribe.

## Cómo se usa cada ventana
- Al seleccionar una fila de la tabla, sus datos pasan a las cajas de texto y se habilitan
  **Actualizar** y **Eliminar** (Guardar se deshabilita).
- **Limpiar** deselecciona y deja el formulario listo para un registro nuevo.
- El ID lo genera la base de datos (solo lectura).

## Validaciones principales
- Campos obligatorios, longitudes máximas según la base y formatos (placa, teléfono, salario, potencia).
- No se permiten duplicados (placa de camión, ciudad, camionero con mismo nombre y teléfono, asignación repetida).
- La base no tiene llaves foráneas, así que la aplicación comprueba las relaciones:
  no se borra un camión, camionero o ciudad que otra tabla esté usando, y los combos
  de camionero/ciudad/camión solo ofrecen registros existentes.
