package umg.UI;

import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import umg.util.ValidacionException;

/** Elemento de un JComboBox: guarda el id de la base y el texto que se muestra. */
public class ItemCombo {

    private final int id;
    private final String texto;

    public ItemCombo(int id, String texto) {
        this.id = id;
        this.texto = texto;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return texto;
    }

    /** Recarga los elementos del combo conservando la selección actual (si sigue existiendo). */
    public static void llenar(JComboBox<ItemCombo> combo, List<ItemCombo> items) {
        ItemCombo actual = (ItemCombo) combo.getSelectedItem();
        int idActual = actual == null ? -1 : actual.getId();
        DefaultComboBoxModel<ItemCombo> modelo = new DefaultComboBoxModel<>();
        for (ItemCombo item : items) {
            modelo.addElement(item);
        }
        combo.setModel(modelo);
        seleccionar(combo, idActual);
    }

    /** Selecciona el elemento con ese id; si no existe, deja el combo sin selección. */
    public static void seleccionar(JComboBox<ItemCombo> combo, int id) {
        combo.setSelectedIndex(-1);
        for (int i = 0; i < combo.getItemCount(); i++) {
            if (combo.getItemAt(i).getId() == id) {
                combo.setSelectedIndex(i);
                return;
            }
        }
    }

    /** Devuelve el id seleccionado o lanza una validación si no hay selección. */
    public static int idSeleccionado(JComboBox<ItemCombo> combo, String campo) throws ValidacionException {
        ItemCombo item = (ItemCombo) combo.getSelectedItem();
        if (item == null) {
            throw new ValidacionException("Selecciona un valor en el campo \"" + campo + "\".");
        }
        return item.getId();
    }
}
