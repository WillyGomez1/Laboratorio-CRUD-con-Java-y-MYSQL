package umg.UI;

import java.awt.Component;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import umg.util.ValidacionException;

/**
 * Utilidades que comparten todas las ventanas CRUD, para que cada formulario
 * solo tenga su diseño y su lógica propia.
 */
public final class UiUtil {

    private UiUtil() {
    }

    /** Acción que puede lanzar errores de base de datos o de validación. */
    public interface Accion {

        void ejecutar() throws SQLException, ValidacionException;
    }

    /** Ejecuta la acción y muestra al usuario los errores de validación o de base de datos. */
    public static void ejecutar(Component padre, Accion accion) {
        try {
            accion.ejecutar();
        } catch (ValidacionException ex) {
            JOptionPane.showMessageDialog(padre, ex.getMessage(), "Validación", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException ex) {
            mostrarError(padre, ex);
        }
    }

    public static void mostrarError(Component padre, SQLException ex) {
        JOptionPane.showMessageDialog(padre, "Error de base de datos:\n" + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void info(Component padre, String mensaje) {
        JOptionPane.showMessageDialog(padre, mensaje, "Información", JOptionPane.INFORMATION_MESSAGE);
    }

    public static boolean confirmar(Component padre, String mensaje) {
        return JOptionPane.showConfirmDialog(padre, mensaje, "Confirmar",
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION;
    }

    /** Modelo de tabla cuyas celdas no se pueden editar a mano. */
    public static DefaultTableModel modeloSoloLectura(String... columnas) {
        return new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };
    }

    /** Selección de una sola fila, filas más altas y columna ID angosta. */
    public static void configurarTabla(JTable tabla) {
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabla.setRowHeight(24);
        tabla.getTableHeader().setReorderingAllowed(false);
        tabla.getColumnModel().getColumn(0).setPreferredWidth(50);
        tabla.getColumnModel().getColumn(0).setMaxWidth(80);
    }

    /** Con una fila seleccionada se puede actualizar o eliminar; sin selección, solo guardar. */
    public static void modoEdicion(JButton guardar, JButton actualizar, JButton eliminar, boolean edicion) {
        guardar.setEnabled(!edicion);
        actualizar.setEnabled(edicion);
        eliminar.setEnabled(edicion);
    }

    /** Lee el ID de la caja de texto (0 si está vacía). */
    public static int id(JTextField txtID) {
        String texto = txtID.getText().trim();
        return texto.isEmpty() ? 0 : Integer.parseInt(texto);
    }

    public static void exigirSeleccion(JTextField txtID) throws ValidacionException {
        if (id(txtID) == 0) {
            throw new ValidacionException("Selecciona un registro de la tabla.");
        }
    }
}
