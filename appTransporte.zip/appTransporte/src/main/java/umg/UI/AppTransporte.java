package umg.UI;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 * Punto de entrada de la aplicación.
 *
 * @author WILLUX
 */
public class AppTransporte {

    public static void main(String[] args) {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            // Si Nimbus no está disponible se usa el aspecto por defecto.
        }
        SwingUtilities.invokeLater(() -> new FrmPrincipal().setVisible(true));
    }
}
