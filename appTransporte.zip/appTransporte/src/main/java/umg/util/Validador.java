package umg.util;

import java.math.BigDecimal;
import java.util.regex.Pattern;

/**
 * Validaciones reutilizables para los formularios.
 * Cada método devuelve el valor ya limpio (sin espacios sobrantes)
 * o lanza una {@link ValidacionException} con un mensaje claro.
 */
public final class Validador {

    private static final Pattern NOMBRE = Pattern.compile("^\\p{L}[\\p{L} .'\\-]*$");
    private static final Pattern PLACA = Pattern.compile("^[A-Za-z0-9][A-Za-z0-9 \\-]{2,44}$");
    private static final Pattern TELEFONO = Pattern.compile("^\\+?[0-9][0-9 \\-]*$");
    private static final Pattern SALARIO = Pattern.compile("^\\d{1,13}(\\.\\d{1,2})?$");

    private Validador() {
    }

    /** Quita espacios al inicio/fin y colapsa espacios repetidos. */
    private static String limpiar(String valor) {
        return valor == null ? "" : valor.trim().replaceAll("\\s+", " ");
    }

    /** Texto obligatorio con longitud máxima. */
    public static String requerido(String valor, String campo, int max) throws ValidacionException {
        String v = limpiar(valor);
        if (v.isEmpty()) {
            throw new ValidacionException("El campo \"" + campo + "\" es obligatorio.");
        }
        if (v.length() > max) {
            throw new ValidacionException("El campo \"" + campo + "\" no puede superar los "
                    + max + " caracteres (tiene " + v.length() + ").");
        }
        return v;
    }

    /** Texto opcional: devuelve null si viene vacío. */
    public static String opcional(String valor, String campo, int max) throws ValidacionException {
        String v = limpiar(valor);
        if (v.isEmpty()) {
            return null;
        }
        return requerido(v, campo, max);
    }

    /** Nombre de persona o lugar: obligatorio y solo letras, espacios, punto, apóstrofo y guion. */
    public static String nombre(String valor, String campo, int max) throws ValidacionException {
        String v = requerido(valor, campo, max);
        if (!NOMBRE.matcher(v).matches()) {
            throw new ValidacionException("El campo \"" + campo
                    + "\" solo puede contener letras, espacios, punto, apóstrofo y guion.");
        }
        return v;
    }

    /** Placa: 3 a 45 caracteres entre letras, números, espacios y guion. Se guarda en mayúsculas. */
    public static String placa(String valor) throws ValidacionException {
        String v = requerido(valor, "No. de placa", 45).toUpperCase();
        if (!PLACA.matcher(v).matches()) {
            throw new ValidacionException("El No. de placa debe tener entre 3 y 45 caracteres y "
                    + "solo puede contener letras, números, espacios y guion (ej. C-123ABC).");
        }
        return v;
    }

    /** Teléfono opcional: entre 8 y 15 dígitos; se aceptan +, espacios y guiones. */
    public static String telefonoOpcional(String valor) throws ValidacionException {
        String v = limpiar(valor);
        if (v.isEmpty()) {
            return null;
        }
        int digitos = v.replaceAll("\\D", "").length();
        if (v.length() > 20 || !TELEFONO.matcher(v).matches() || digitos < 8 || digitos > 15) {
            throw new ValidacionException("El teléfono debe tener entre 8 y 15 dígitos "
                    + "(se permiten +, espacios y guiones). Ej. 5555-1234.");
        }
        return v;
    }

    /** Entero opcional dentro de un rango. Devuelve null si viene vacío. */
    public static Integer enteroOpcional(String valor, String campo, int min, int max)
            throws ValidacionException {
        String v = limpiar(valor);
        if (v.isEmpty()) {
            return null;
        }
        int numero;
        try {
            numero = Integer.parseInt(v);
        } catch (NumberFormatException ex) {
            throw new ValidacionException("El campo \"" + campo + "\" debe ser un número entero.");
        }
        if (numero < min || numero > max) {
            throw new ValidacionException("El campo \"" + campo + "\" debe estar entre "
                    + min + " y " + max + ".");
        }
        return numero;
    }

    /** Salario obligatorio: mayor que cero, hasta 2 decimales. */
    public static double salario(String valor) throws ValidacionException {
        String v = limpiar(valor).replace(",", "");
        if (v.isEmpty()) {
            throw new ValidacionException("El campo \"Salario\" es obligatorio.");
        }
        if (!SALARIO.matcher(v).matches()) {
            throw new ValidacionException("El salario debe ser un número positivo con máximo "
                    + "2 decimales (ej. 3500.50).");
        }
        BigDecimal monto = new BigDecimal(v);
        if (monto.signum() <= 0) {
            throw new ValidacionException("El salario debe ser mayor que cero.");
        }
        return monto.doubleValue();
    }
}
