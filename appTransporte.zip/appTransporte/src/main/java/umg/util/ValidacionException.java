package umg.util;

/**
 * Se lanza cuando un dato no cumple una regla de validación
 * (campo vacío, formato incorrecto, registro duplicado, relación activa, etc.).
 * El mensaje es apto para mostrarse directamente al usuario.
 */
public class ValidacionException extends Exception {

    public ValidacionException(String mensaje) {
        super(mensaje);
    }
}
