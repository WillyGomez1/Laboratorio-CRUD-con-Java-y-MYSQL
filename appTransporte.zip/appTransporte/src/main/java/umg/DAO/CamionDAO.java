package umg.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import umg.modelo.Camion;
import umg.util.ValidacionException;

public class CamionDAO {

    private static final String SQL_PLACA_DUPLICADA
            = "SELECT 1 FROM camion WHERE LOWER(NoPlaca)=LOWER(?) AND idCamion<>? LIMIT 1";

    public void insertar(Camion c) throws SQLException, ValidacionException {
        try (Connection cn = ConexionDB.abrir()) {
            if (DaoUtil.existe(cn, SQL_PLACA_DUPLICADA, c.getNoPlaca(), 0)) {
                throw new ValidacionException("Ya existe un camión con la placa " + c.getNoPlaca() + ".");
            }
            try (PreparedStatement ps = cn.prepareStatement(
                    "INSERT INTO camion (NoPlaca, Modelo, Tipo, Potencia) VALUES (?,?,?,?)")) {
                asignar(ps, c);
                ps.executeUpdate();
            }
        }
    }

    public void actualizar(Camion c) throws SQLException, ValidacionException {
        try (Connection cn = ConexionDB.abrir()) {
            if (DaoUtil.existe(cn, SQL_PLACA_DUPLICADA, c.getNoPlaca(), c.getIdCamion())) {
                throw new ValidacionException("Ya existe otro camión con la placa " + c.getNoPlaca() + ".");
            }
            try (PreparedStatement ps = cn.prepareStatement(
                    "UPDATE camion SET NoPlaca=?, Modelo=?, Tipo=?, Potencia=? WHERE idCamion=?")) {
                asignar(ps, c);
                ps.setInt(5, c.getIdCamion());
                DaoUtil.exigirFila(ps.executeUpdate());
            }
        }
    }

    public void eliminar(int idCamion) throws SQLException, ValidacionException {
        try (Connection cn = ConexionDB.abrir()) {
            if (DaoUtil.existe(cn, "SELECT 1 FROM camionerocamion WHERE idCamion=? LIMIT 1", idCamion)) {
                throw new ValidacionException(
                        "No se puede eliminar el camión porque está asignado a uno o más camioneros.");
            }
            try (PreparedStatement ps = cn.prepareStatement("DELETE FROM camion WHERE idCamion=?")) {
                ps.setInt(1, idCamion);
                DaoUtil.exigirFila(ps.executeUpdate());
            }
        }
    }

    public List<Camion> listar() throws SQLException {
        List<Camion> lista = new ArrayList<>();
        try (Connection cn = ConexionDB.abrir();
                PreparedStatement ps = cn.prepareStatement(
                        "SELECT idCamion, NoPlaca, Modelo, Tipo, Potencia FROM camion ORDER BY idCamion");
                ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                int potencia = rs.getInt("Potencia");
                Integer pot = rs.wasNull() ? null : potencia;
                lista.add(new Camion(rs.getInt("idCamion"), rs.getString("NoPlaca"),
                        rs.getString("Modelo"), rs.getString("Tipo"), pot));
            }
        }
        return lista;
    }

    private void asignar(PreparedStatement ps, Camion c) throws SQLException {
        ps.setString(1, c.getNoPlaca());
        ps.setString(2, c.getModelo());
        ps.setString(3, c.getTipo());
        if (c.getPotencia() == null) {
            ps.setNull(4, Types.INTEGER);
        } else {
            ps.setInt(4, c.getPotencia());
        }
    }
}
