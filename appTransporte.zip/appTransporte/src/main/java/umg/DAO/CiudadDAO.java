package umg.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import umg.modelo.Ciudad;
import umg.util.ValidacionException;

public class CiudadDAO {

    private static final String SQL_DUPLICADO
            = "SELECT 1 FROM ciudad WHERE LOWER(Nombre)=LOWER(?) AND idCiudad<>? LIMIT 1";

    public void insertar(Ciudad c) throws SQLException, ValidacionException {
        try (Connection cn = ConexionDB.abrir()) {
            if (DaoUtil.existe(cn, SQL_DUPLICADO, c.getNombre(), 0)) {
                throw new ValidacionException("Ya existe una ciudad llamada \"" + c.getNombre() + "\".");
            }
            try (PreparedStatement ps = cn.prepareStatement(
                    "INSERT INTO ciudad (Nombre) VALUES (?)", Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, c.getNombre());
                ps.executeUpdate();
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) {
                        c.setIdCiudad(keys.getInt(1));
                    }
                }
            }
        }
    }

    public void actualizar(Ciudad c) throws SQLException, ValidacionException {
        try (Connection cn = ConexionDB.abrir()) {
            if (DaoUtil.existe(cn, SQL_DUPLICADO, c.getNombre(), c.getIdCiudad())) {
                throw new ValidacionException("Ya existe otra ciudad llamada \"" + c.getNombre() + "\".");
            }
            try (PreparedStatement ps = cn.prepareStatement(
                    "UPDATE ciudad SET Nombre=? WHERE idCiudad=?")) {
                ps.setString(1, c.getNombre());
                ps.setInt(2, c.getIdCiudad());
                DaoUtil.exigirFila(ps.executeUpdate());
            }
        }
    }

    public void eliminar(int idCiudad) throws SQLException, ValidacionException {
        try (Connection cn = ConexionDB.abrir()) {
            if (DaoUtil.existe(cn, "SELECT 1 FROM paquete WHERE idCiudad=? LIMIT 1", idCiudad)) {
                throw new ValidacionException(
                        "No se puede eliminar la ciudad porque tiene paquetes asociados.");
            }
            try (PreparedStatement ps = cn.prepareStatement("DELETE FROM ciudad WHERE idCiudad=?")) {
                ps.setInt(1, idCiudad);
                DaoUtil.exigirFila(ps.executeUpdate());
            }
        }
    }

    public List<Ciudad> listar() throws SQLException {
        List<Ciudad> lista = new ArrayList<>();
        try (Connection cn = ConexionDB.abrir();
                PreparedStatement ps = cn.prepareStatement(
                        "SELECT idCiudad, Nombre FROM ciudad ORDER BY idCiudad");
                ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(new Ciudad(rs.getInt("idCiudad"), rs.getString("Nombre")));
            }
        }
        return lista;
    }
}
