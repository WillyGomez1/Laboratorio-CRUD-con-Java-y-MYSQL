package umg.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import umg.util.ValidacionException;

/** Utilidades compartidas por los DAO. */
final class DaoUtil {

    private DaoUtil() {
    }

    /** Ejecuta un SELECT 1 ... y devuelve true si hay al menos una fila. */
    static boolean existe(Connection cn, String sql, Object... parametros) throws SQLException {
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            for (int i = 0; i < parametros.length; i++) {
                ps.setObject(i + 1, parametros[i]);
            }
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    /** Si el UPDATE/DELETE no afectó ninguna fila, el registro ya no existe. */
    static void exigirFila(int filas) throws ValidacionException {
        if (filas == 0) {
            throw new ValidacionException("El registro ya no existe en la base de datos. "
                    + "Actualiza la lista e inténtalo de nuevo.");
        }
    }
}
