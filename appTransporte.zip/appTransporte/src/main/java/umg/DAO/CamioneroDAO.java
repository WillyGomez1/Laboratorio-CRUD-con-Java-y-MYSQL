package umg.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import umg.modelo.Camionero;
import umg.util.ValidacionException;

public class CamioneroDAO {

    /** Duplicado = mismo nombre y mismo teléfono (<=> compara también valores NULL). */
    private static final String SQL_DUPLICADO
            = "SELECT 1 FROM camionero WHERE LOWER(Nombre)=LOWER(?) AND Telefono <=> ? "
            + "AND idCamionero<>? LIMIT 1";

    public void insertar(Camionero c) throws SQLException, ValidacionException {
        try (Connection cn = ConexionDB.abrir()) {
            if (DaoUtil.existe(cn, SQL_DUPLICADO, c.getNombre(), c.getTelefono(), 0)) {
                throw new ValidacionException("Ya existe un camionero con el mismo nombre y teléfono.");
            }
            try (PreparedStatement ps = cn.prepareStatement(
                    "INSERT INTO camionero (Nombre, Telefono, Direccion, Salario, Poblacion) "
                    + "VALUES (?,?,?,?,?)")) {
                asignar(ps, c);
                ps.executeUpdate();
            }
        }
    }

    public void actualizar(Camionero c) throws SQLException, ValidacionException {
        try (Connection cn = ConexionDB.abrir()) {
            if (DaoUtil.existe(cn, SQL_DUPLICADO, c.getNombre(), c.getTelefono(), c.getIdCamionero())) {
                throw new ValidacionException("Ya existe otro camionero con el mismo nombre y teléfono.");
            }
            try (PreparedStatement ps = cn.prepareStatement(
                    "UPDATE camionero SET Nombre=?, Telefono=?, Direccion=?, Salario=?, Poblacion=? "
                    + "WHERE idCamionero=?")) {
                asignar(ps, c);
                ps.setInt(6, c.getIdCamionero());
                DaoUtil.exigirFila(ps.executeUpdate());
            }
        }
    }

    public void eliminar(int idCamionero) throws SQLException, ValidacionException {
        try (Connection cn = ConexionDB.abrir()) {
            if (DaoUtil.existe(cn, "SELECT 1 FROM camionerocamion WHERE idCamionero=? LIMIT 1", idCamionero)) {
                throw new ValidacionException(
                        "No se puede eliminar el camionero porque tiene camiones asignados.");
            }
            if (DaoUtil.existe(cn, "SELECT 1 FROM paquete WHERE idCamionero=? LIMIT 1", idCamionero)) {
                throw new ValidacionException(
                        "No se puede eliminar el camionero porque tiene paquetes asignados.");
            }
            try (PreparedStatement ps = cn.prepareStatement("DELETE FROM camionero WHERE idCamionero=?")) {
                ps.setInt(1, idCamionero);
                DaoUtil.exigirFila(ps.executeUpdate());
            }
        }
    }

    public List<Camionero> listar() throws SQLException {
        List<Camionero> lista = new ArrayList<>();
        try (Connection cn = ConexionDB.abrir();
                PreparedStatement ps = cn.prepareStatement(
                        "SELECT idCamionero, Nombre, Telefono, Direccion, Salario, Poblacion "
                        + "FROM camionero ORDER BY idCamionero");
                ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(new Camionero(rs.getInt("idCamionero"), rs.getString("Nombre"),
                        rs.getString("Telefono"), rs.getString("Direccion"),
                        rs.getDouble("Salario"), rs.getString("Poblacion")));
            }
        }
        return lista;
    }

    private void asignar(PreparedStatement ps, Camionero c) throws SQLException {
        ps.setString(1, c.getNombre());
        ps.setString(2, c.getTelefono());
        ps.setString(3, c.getDireccion());
        ps.setDouble(4, c.getSalario());
        ps.setString(5, c.getPoblacion());
    }
}
