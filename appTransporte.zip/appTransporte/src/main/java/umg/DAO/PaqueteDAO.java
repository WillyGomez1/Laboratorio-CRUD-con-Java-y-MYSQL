package umg.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import umg.modelo.Paquete;
import umg.util.ValidacionException;

public class PaqueteDAO {

    public void insertar(Paquete p) throws SQLException, ValidacionException {
        try (Connection cn = ConexionDB.abrir()) {
            validar(cn, p);
            try (PreparedStatement ps = cn.prepareStatement(
                    "INSERT INTO paquete (Descripcion, Destinatario, DireccionEnvio, idCamionero, idCiudad) "
                    + "VALUES (?,?,?,?,?)")) {
                asignar(ps, p);
                ps.executeUpdate();
            }
        }
    }

    public void actualizar(Paquete p) throws SQLException, ValidacionException {
        try (Connection cn = ConexionDB.abrir()) {
            validar(cn, p);
            try (PreparedStatement ps = cn.prepareStatement(
                    "UPDATE paquete SET Descripcion=?, Destinatario=?, DireccionEnvio=?, "
                    + "idCamionero=?, idCiudad=? WHERE idPaquete=?")) {
                asignar(ps, p);
                ps.setInt(6, p.getIdPaquete());
                DaoUtil.exigirFila(ps.executeUpdate());
            }
        }
    }

    public void eliminar(int idPaquete) throws SQLException, ValidacionException {
        try (Connection cn = ConexionDB.abrir();
                PreparedStatement ps = cn.prepareStatement("DELETE FROM paquete WHERE idPaquete=?")) {
            ps.setInt(1, idPaquete);
            DaoUtil.exigirFila(ps.executeUpdate());
        }
    }

    public List<Paquete> listar() throws SQLException {
        List<Paquete> lista = new ArrayList<>();
        String sql = "SELECT p.idPaquete, p.Descripcion, p.Destinatario, p.DireccionEnvio, "
                + "p.idCamionero, co.Nombre AS nombreCamionero, p.idCiudad, ci.Nombre AS nombreCiudad "
                + "FROM paquete p "
                + "LEFT JOIN camionero co ON co.idCamionero = p.idCamionero "
                + "LEFT JOIN ciudad ci ON ci.idCiudad = p.idCiudad "
                + "ORDER BY p.idPaquete";
        try (Connection cn = ConexionDB.abrir();
                PreparedStatement ps = cn.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Paquete p = new Paquete();
                p.setIdPaquete(rs.getInt("idPaquete"));
                p.setDescripcion(rs.getString("Descripcion"));
                p.setDestinatario(rs.getString("Destinatario"));
                p.setDireccionEnvio(rs.getString("DireccionEnvio"));
                p.setIdCamionero(rs.getInt("idCamionero"));
                p.setNombreCamionero(rs.getString("nombreCamionero"));
                p.setIdCiudad(rs.getInt("idCiudad"));
                p.setNombreCiudad(rs.getString("nombreCiudad"));
                lista.add(p);
            }
        }
        return lista;
    }

    private void asignar(PreparedStatement ps, Paquete p) throws SQLException {
        ps.setString(1, p.getDescripcion());
        ps.setString(2, p.getDestinatario());
        ps.setString(3, p.getDireccionEnvio());
        ps.setInt(4, p.getIdCamionero());
        ps.setInt(5, p.getIdCiudad());
    }

    /** La base no tiene llaves foráneas, por eso se comprueban aquí las relaciones. */
    private void validar(Connection cn, Paquete p) throws SQLException, ValidacionException {
        if (!DaoUtil.existe(cn, "SELECT 1 FROM camionero WHERE idCamionero=?", p.getIdCamionero())) {
            throw new ValidacionException("El camionero seleccionado ya no existe.");
        }
        if (!DaoUtil.existe(cn, "SELECT 1 FROM ciudad WHERE idCiudad=?", p.getIdCiudad())) {
            throw new ValidacionException("La ciudad seleccionada ya no existe.");
        }
    }
}
