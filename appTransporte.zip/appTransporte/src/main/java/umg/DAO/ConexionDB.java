package umg.DAO;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Abre conexiones a MySQL leyendo los datos de src/main/resources/db.properties.
 * Ese archivo NO se sube a GitHub (está en .gitignore); el repositorio incluye
 * db.properties.example como plantilla.
 */
public class ConexionDB {

    private static Properties config;

    private static synchronized Properties config() throws SQLException {
        if (config == null) {
            try (InputStream in = ConexionDB.class.getResourceAsStream("/db.properties")) {
                if (in == null) {
                    throw new SQLException("No se encontró db.properties en src/main/resources. "
                            + "Copia db.properties.example como db.properties y escribe tus datos.");
                }
                Properties p = new Properties();
                p.load(new InputStreamReader(in, StandardCharsets.UTF_8));
                config = p;
            } catch (IOException ex) {
                throw new SQLException("No se pudo leer db.properties: " + ex.getMessage(), ex);
            }
        }
        return config;
    }

    public static Connection abrir() throws SQLException {
        Properties p = config();
        String url = "jdbc:mysql://" + p.getProperty("db.host", "localhost").trim()
                + ":" + p.getProperty("db.port", "3306").trim()
                + "/" + p.getProperty("db.name", "db_paqueteria").trim()
                + "?useSSL=false"
                + "&allowPublicKeyRetrieval=true"
                + "&serverTimezone=America/Guatemala";
        return DriverManager.getConnection(url,
                p.getProperty("db.user", "root").trim(),
                p.getProperty("db.password", "").trim());
    }
}
