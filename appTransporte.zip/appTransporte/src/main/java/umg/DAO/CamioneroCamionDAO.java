package umg.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import umg.modelo.CamioneroCamion;
import umg.util.ValidacionException;

public class CamioneroCamionDAO {

    public void insertar(CamioneroCamion cc) throws SQLException, ValidacionException {
        try (Connection cn = ConexionDB.abrir()) {
            validar(cn, cc, 0);
            try (PreparedStatement ps = cn.prepareStatement(
                    "INSERT INTO camionerocamion (idCamionero, idCamion) VALUES (?,?)")) {
                ps.setInt(1, cc.getIdCamionero());
                ps.setInt(2, cc.getIdCamion());
                ps.executeUpdate();
            }
        }
    }

    public void actualizar(CamioneroCamion cc) throws SQLException, ValidacionException {
        try (Connection cn = ConexionDB.abrir()) {
            validar(cn, cc, cc.getIdCamioneroCamion());
            try (PreparedStatement ps = cn.prepareStatement(
                    "UPDATE camionerocamion SET idCamionero=?, idCamion=? WHERE idCamioneroCamion=?")) {
                ps.setInt(1, cc.getIdCamionero());
                ps.setInt(2, cc.getIdCamion());
                ps.setInt(3, cc.getIdCamioneroCamion());
                DaoUtil.exigirFila(ps.executeUpdate());
            }
        }
    }

    public void eliminar(int idCamioneroCamion) throws SQLException, ValidacionException {
        try (Connection cn = ConexionDB.abrir();
                PreparedStatement ps = cn.prepareStatement(
                        "DELETE FROM camionerocamion WHERE idCamioneroCamion=?")) {
            ps.setInt(1, idCamioneroCamion);
            DaoUtil.exigirFila(ps.executeUpdate());
        }
    }

    public List<CamioneroCamion> listar() throws SQLException {
        List<CamioneroCamion> lista = new ArrayList<>();
        String sql = "SELECT cc.idCamioneroCamion, cc.idCamionero, co.Nombre, cc.idCamion, c.NoPlaca "
                + "FROM camionerocamion cc "
                + "LEFT JOIN camionero co ON co.idCamionero = cc.idCamionero "
                + "LEFT JOIN camion c ON c.idCamion = cc.idCamion "
                + "ORDER BY cc.idCamioneroCamion";
        try (Connection cn = ConexionDB.abrir();
                PreparedStatement ps = cn.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                CamioneroCamion cc = new CamioneroCamion();
                cc.setIdCamioneroCamion(rs.getInt("idCamioneroCamion"));
                cc.setIdCamionero(rs.getInt("idCamionero"));
                cc.setNombreCamionero(rs.getString("Nombre"));
                cc.setIdCamion(rs.getInt("idCamion")); // NULL -> 0
                cc.setPlacaCamion(rs.getString("NoPlaca"));
                lista.add(cc);
            }
        }
        return lista;
    }

    /** La base no tiene llaves foráneas, por eso se comprueban aquí las relaciones. */
    private void validar(Connection cn, CamioneroCamion cc, int idExcluir)
            throws SQLException, ValidacionException {
        if (!DaoUtil.existe(cn, "SELECT 1 FROM camionero WHERE idCamionero=?", cc.getIdCamionero())) {
            throw new ValidacionException("El camionero seleccionado ya no existe.");
        }
        if (!DaoUtil.existe(cn, "SELECT 1 FROM camion WHERE idCamion=?", cc.getIdCamion())) {
            throw new ValidacionException("El camión seleccionado ya no existe.");
        }
        if (DaoUtil.existe(cn, "SELECT 1 FROM camionerocamion WHERE idCamionero=? AND idCamion=? "
                + "AND idCamioneroCamion<>? LIMIT 1", cc.getIdCamionero(), cc.getIdCamion(), idExcluir)) {
            throw new ValidacionException("Ese camionero ya tiene asignado ese camión.");
        }
    }
}
