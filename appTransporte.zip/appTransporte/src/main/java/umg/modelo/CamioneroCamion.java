package umg.modelo;

/**
 * Asignación de un camionero a un camión (tabla camionerocamion).
 * Los campos nombreCamionero y placaCamion solo sirven para mostrar datos en pantalla.
 */
public class CamioneroCamion {

    private int idCamioneroCamion;
    private int idCamionero;
    private int idCamion; // 0 = sin camión (la columna permite NULL en la base)
    private String nombreCamionero;
    private String placaCamion;

    public CamioneroCamion() {
    }

    public CamioneroCamion(int idCamioneroCamion, int idCamionero, int idCamion) {
        this.idCamioneroCamion = idCamioneroCamion;
        this.idCamionero = idCamionero;
        this.idCamion = idCamion;
    }

    public int getIdCamioneroCamion() {
        return idCamioneroCamion;
    }

    public void setIdCamioneroCamion(int idCamioneroCamion) {
        this.idCamioneroCamion = idCamioneroCamion;
    }

    public int getIdCamionero() {
        return idCamionero;
    }

    public void setIdCamionero(int idCamionero) {
        this.idCamionero = idCamionero;
    }

    public int getIdCamion() {
        return idCamion;
    }

    public void setIdCamion(int idCamion) {
        this.idCamion = idCamion;
    }

    public String getNombreCamionero() {
        return nombreCamionero;
    }

    public void setNombreCamionero(String nombreCamionero) {
        this.nombreCamionero = nombreCamionero;
    }

    public String getPlacaCamion() {
        return placaCamion;
    }

    public void setPlacaCamion(String placaCamion) {
        this.placaCamion = placaCamion;
    }

    @Override
    public String toString() {
        return "CamioneroCamion{" + "idCamioneroCamion=" + idCamioneroCamion + ", idCamionero=" + idCamionero
                + ", idCamion=" + idCamion + '}';
    }
}
