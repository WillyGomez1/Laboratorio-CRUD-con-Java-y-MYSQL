package umg.modelo;

/**
 * Paquete (tabla paquete). Los campos nombreCamionero y nombreCiudad
 * solo sirven para mostrar datos en pantalla.
 */
public class Paquete {

    private int idPaquete;
    private String descripcion;
    private String destinatario;
    private String direccionEnvio;
    private int idCamionero;
    private int idCiudad;
    private String nombreCamionero;
    private String nombreCiudad;

    public Paquete() {
    }

    public int getIdPaquete() {
        return idPaquete;
    }

    public void setIdPaquete(int idPaquete) {
        this.idPaquete = idPaquete;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getDestinatario() {
        return destinatario;
    }

    public void setDestinatario(String destinatario) {
        this.destinatario = destinatario;
    }

    public String getDireccionEnvio() {
        return direccionEnvio;
    }

    public void setDireccionEnvio(String direccionEnvio) {
        this.direccionEnvio = direccionEnvio;
    }

    public int getIdCamionero() {
        return idCamionero;
    }

    public void setIdCamionero(int idCamionero) {
        this.idCamionero = idCamionero;
    }

    public int getIdCiudad() {
        return idCiudad;
    }

    public void setIdCiudad(int idCiudad) {
        this.idCiudad = idCiudad;
    }

    public String getNombreCamionero() {
        return nombreCamionero;
    }

    public void setNombreCamionero(String nombreCamionero) {
        this.nombreCamionero = nombreCamionero;
    }

    public String getNombreCiudad() {
        return nombreCiudad;
    }

    public void setNombreCiudad(String nombreCiudad) {
        this.nombreCiudad = nombreCiudad;
    }

    @Override
    public String toString() {
        return "Paquete{" + "idPaquete=" + idPaquete + ", descripcion=" + descripcion + ", destinatario="
                + destinatario + ", direccionEnvio=" + direccionEnvio + ", idCamionero=" + idCamionero
                + ", idCiudad=" + idCiudad + '}';
    }
}
